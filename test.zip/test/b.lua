module('test.b')

local M = {}

function M.print(msg)
    print(msg)
end

return M
